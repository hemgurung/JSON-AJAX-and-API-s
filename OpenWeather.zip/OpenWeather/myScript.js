/*This is my script for the open weather API*/

var theButton = document.getElementById("myButton");

theButton.addEventListener("click", getWeather, false); 


function getWeather() {
    
var userCity = document.getElementById("theCity").value;

//console.log(userCity);
    
var theAPICall = "";
    
var myRequest = new XMLHttpRequest();
    
myRequest.open("GET", theAPICall, true);   
//console.log(myRequest);
    
myRequest.send();
    
myRequest.onload  = function() {
    
    if (myRequest.readyState == 4 && myRequest.status == 200) {
        
        var myData  = JSON.parse(myRequest.responseText);
        //console.log(myData);
        
       
        
        
        
        
    }
  }

}
